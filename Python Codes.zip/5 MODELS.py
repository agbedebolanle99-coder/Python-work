import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from lightgbm import LGBMClassifier

from sklearn.metrics import confusion_matrix
from imblearn.over_sampling import SMOTE

df = pd.read_csv("synthetic_pipe_failure_dataset.csv")

# Encode categorical variables
df["material"] = df["material"].astype("category").cat.codes
df["soil_type"] = df["soil_type"].astype("category").cat.codes
df["failure"] = df["failure"].astype("category").cat.codes

X = df.drop("failure", axis=1)
y = df["failure"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

smote = SMOTE(random_state=42)
X_train_bal, y_train_bal = smote.fit_resample(X_train_scaled, y_train)

models = {
    "LightGBM": LGBMClassifier(),
    "ANN": MLPClassifier(max_iter=500),
    "LR": LogisticRegression(max_iter=500),
    "kNN": KNeighborsClassifier(),
    "SVC": SVC()
}
def compute_table(cm):
    TN, FP, FN, TP = cm.ravel()

    recall_I = TN / (TN + FP)
    recall_B = TP / (TP + FN)

    precision_I = TN / (TN + FN)
    precision_B = TP / (TP + FP)

    return [
        [TN, FP, f"{recall_I:.3f}"],
        [FN, TP, f"{recall_B:.3f}"],
        [f"{precision_I:.3f}", f"{precision_B:.3f}", ""]
    ]

results_imbal = {}
results_bal = {}

for name, model in models.items():
    # --- Imbalanced training ---
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    cm = confusion_matrix(y_test, y_pred)
    results_imbal[name] = compute_table(cm)

    # --- Balanced training (SMOTE) ---
    model.fit(X_train_bal, y_train_bal)
    y_pred_bal = model.predict(X_test_scaled)
    cm_bal = confusion_matrix(y_test, y_pred_bal)
    results_bal[name] = compute_table(cm_bal)

import matplotlib.pyplot as plt

def plot_results(results, title):
    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    axes = axes.flatten()

    for i, (name, table_data) in enumerate(results.items()):
        ax = axes[i]

        table = ax.table(
            cellText=table_data,
            rowLabels=["I", "B", "Precision"],
            colLabels=["I", "B", "Recall"],
            loc="center",
            cellLoc="center"
        )

        table.scale(1, 2)
        ax.set_title(f"{name} model", fontsize=12)
        ax.axis("off")

    # remove last empty subplot
    fig.delaxes(axes[-1])

    plt.suptitle(title, fontsize=16)
    plt.tight_layout()
    plt.show()

plot_results(results_imbal, "a) Test results (Imbalanced data)")
plot_results(results_bal, "b) Test results (SMOTE balanced data)")