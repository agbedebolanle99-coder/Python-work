import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix

from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from lightgbm import LGBMClassifier

from imblearn.over_sampling import SMOTE

# =========================
# LOAD DATA
# =========================
df = pd.read_csv("synthetic_pipe_failure_dataset.csv")

# Target
y = df["failure"]

# Features
X = df.drop(columns=["failure"])

# One-hot encoding (important!)
X = pd.get_dummies(X, drop_first=True)

# =========================
# TRAIN TEST SPLIT
# =========================
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# =========================
# SCALE DATA (important for ANN, SVM, KNN)
# =========================
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# =========================
# APPLY SMOTE (ONLY TRAIN SET)
# =========================
smote = SMOTE(random_state=42)
X_train_bal, y_train_bal = smote.fit_resample(X_train_scaled, y_train)

# =========================
# MODELS
# =========================
models = {
    "LightGBM": LGBMClassifier(),
    "ANN": MLPClassifier(hidden_layer_sizes=(50, 50), max_iter=500),
    "LR": LogisticRegression(max_iter=1000),
    "kNN": KNeighborsClassifier(n_neighbors=5),
    "SVC": SVC(probability=True)
}

# =========================
# FUNCTION TO PRINT TABLE LIKE PAPER
# =========================
def print_results(name, y_true, y_pred):
    cm = confusion_matrix(y_true, y_pred)

    TN, FP, FN, TP = cm.ravel()

    # Precision
    precision_I = TP / (TP + FP) if (TP + FP) != 0 else 0
    precision_B = TN / (TN + FN) if (TN + FN) != 0 else 0

    # Recall
    recall_I = TP / (TP + FN) if (TP + FN) != 0 else 0
    recall_B = TN / (TN + FP) if (TN + FP) != 0 else 0

    print(f"\n{name}")
    print("Predicted:     I        B")
    print(f"True I     {TP:5d}   {FN:5d}   Recall={recall_I:.3f}")
    print(f"True B     {FP:5d}   {TN:5d}   Recall={recall_B:.3f}")
    print(f"Precision  {precision_I:.3f}   {precision_B:.3f}")

# =========================
# 🔴 CASE 1: IMBALANCED DATA
# =========================
print("\n================ IMBALANCED DATA ================")

for name, model in models.items():
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    print_results(name, y_test, y_pred)

# =========================
# 🟢 CASE 2: BALANCED DATA (SMOTE)
# =========================
print("\n================ BALANCED DATA (SMOTE) ================")

for name, model in models.items():
    model.fit(X_train_bal, y_train_bal)
    y_pred = model.predict(X_test_scaled)
    print_results(name, y_test, y_pred)

