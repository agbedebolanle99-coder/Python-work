import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import time

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score, average_precision_score

from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC

from imblearn.over_sampling import SMOTE
df = pd.read_csv("synthetic_pipe_failure_dataset.csv")

X = df.drop("failure", axis=1)
y = df["failure"]
from sklearn.metrics import roc_auc_score, average_precision_score
import matplotlib.pyplot as plt
import time
def evaluate_models(X_train, y_train, X_test, y_test, models):
    roc_scores = []
    prc_scores = []
    times = []

    for name, model in models.items():
        start = time.time()

        model.fit(X_train, y_train)

        end = time.time()
        train_time = end - start

        # Probabilities (needed for ROC & PRC)
        if hasattr(model, "predict_proba"):
            y_prob = model.predict_proba(X_test)[:, 1]
        else:
            y_prob = model.decision_function(X_test)

        roc = roc_auc_score(y_test, y_prob)
        prc = average_precision_score(y_test, y_prob)

        roc_scores.append(roc)
        prc_scores.append(prc)
        times.append(train_time)

    return roc_scores, prc_scores, times

from sklearn.model_selection import train_test_split
X = pd.get_dummies(X, drop_first=True)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()

X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)
from imblearn.over_sampling import SMOTE

smote = SMOTE(random_state=42)

X_train_bal, y_train_bal = smote.fit_resample(X_train_scaled, y_train)

from lightgbm import LGBMClassifier
from sklearn.neural_network import MLPClassifier

models = {
    "LightGBM": LGBMClassifier(),
    "ANN": MLPClassifier(hidden_layer_sizes=(50, 50), max_iter=500),
    "LR": LogisticRegression(max_iter=1000),
    "kNN": KNeighborsClassifier(n_neighbors=5),
    "SVC": SVC(probability=True)
}
# 🔴 Imbalanced
roc_imb, prc_imb, time_imb = evaluate_models(
    X_train_scaled, y_train, X_test_scaled, y_test, models
)

# 🟢 Balanced (SMOTE)
roc_bal, prc_bal, time_bal = evaluate_models(
    X_train_bal, y_train_bal, X_test_scaled, y_test, models
)

labels = list(models.keys())
x = range(len(labels))
width = 0.25

fig, axes = plt.subplots(1, 2, figsize=(14, 5))

def plot_panel(ax, roc, prc, times, title):
    metrics = ["ROC", "PRC", "Time"]
    data = [roc, prc, times]

    for i, metric in enumerate(metrics):
        ax.bar(
            [j + i*0.15 for j in range(len(labels))],
            data[i],
            width=0.15,
            label=metric
        )

    ax.set_xticks(range(len(labels)))
    ax.set_xticklabels(labels)
    ax.set_title(title)
    ax.legend()

plot_panel(axes[0], roc_imb, prc_imb, time_imb,
           "(a) trained with imbalanced dataset")

plot_panel(axes[1], roc_bal, prc_bal, time_bal,
           "(b) trained with balanced dataset")

plt.show()
