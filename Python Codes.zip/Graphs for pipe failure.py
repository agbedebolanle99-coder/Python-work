import pandas as pd
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt

# Load data
df = pd.read_csv("synthetic_pipe_failure_dataset.csv")

# Split
train_df, test_df = train_test_split(df, test_size=0.2, random_state=42)

# ✅ 3x3 grid = 9 plots
fig, axes = plt.subplots(3, 3, figsize=(15, 10))
axes = axes.flatten()

# -----------------------------
# 1. Soil type (categorical)
# -----------------------------
train_counts = train_df["soil_type"].value_counts()
test_counts = test_df["soil_type"].value_counts()

categories = sorted(set(train_counts.index).union(set(test_counts.index)))

train_vals = [train_counts.get(cat, 0) for cat in categories]
test_vals = [test_counts.get(cat, 0) for cat in categories]

axes[0].bar(categories, train_vals, alpha=0.7, label="Training set")
axes[0].bar(categories, test_vals, alpha=0.7, label="Test set")
axes[0].set_title("Soil type")
axes[0].legend()

# -----------------------------
# 2–7 Numerical variables
# -----------------------------
features = [
    "elevation",
    "cold_days",
    "hot_days",
    "population",
    "poverty_percentage",
    "no_health_insurance"
]

for i, feature in enumerate(features, start=1):
    axes[i].hist(train_df[feature], bins=30, alpha=0.7, label="Training set")
    axes[i].hist(test_df[feature], bins=30, alpha=0.7, label="Test set")
    axes[i].set_title(feature)
    axes[i].legend()

# -----------------------------
# 8. Failure (categorical)
# -----------------------------
train_counts = train_df["failure"].value_counts()
test_counts = test_df["failure"].value_counts()

categories = sorted(set(train_counts.index).union(set(test_counts.index)))

train_vals = [train_counts.get(cat, 0) for cat in categories]
test_vals = [test_counts.get(cat, 0) for cat in categories]

axes[7].bar(categories, train_vals, alpha=0.7, label="Training set")
axes[7].bar(categories, test_vals, alpha=0.7, label="Test set")
axes[7].set_title("Failure")
axes[7].legend()

# -----------------------------
# Remove empty subplot (index 8)
# -----------------------------
fig.delaxes(axes[8])

# Layout
plt.tight_layout()
plt.show()