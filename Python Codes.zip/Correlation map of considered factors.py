import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

# Load dataset
df = pd.read_csv("synthetic_pipe_failure_dataset.csv")

# -----------------------------
# Convert categorical variables to numeric
# -----------------------------
df_encoded = df.copy()

# Encode categorical columns
categorical_cols = ["material", "soil_type"]

for col in categorical_cols:
    df_encoded[col] = df_encoded[col].astype("category").cat.codes

# If "failure" is categorical (Yes/No), convert it too
df_encoded["failure"] = df_encoded["failure"].astype("category").cat.codes

# -----------------------------
# Compute correlation matrix
# -----------------------------
corr = df_encoded.corr()

# -----------------------------
# Create triangular mask
# -----------------------------
mask = np.triu(np.ones_like(corr, dtype=bool))

# -----------------------------
# Plot heatmap
# -----------------------------
plt.figure(figsize=(12, 10))

sns.heatmap(
    corr,
    mask=mask,              # show only lower triangle
    annot=True,             # show numbers
    fmt=".2f",
    cmap="coolwarm",
    vmin=-0.4, vmax=1.0,    # match your scale
    square=True,
    linewidths=0.5,
    cbar_kws={"shrink": 0.8}
)

plt.title("Correlation Matrix of Pipe Failure Dataset", fontsize=14)
plt.xticks(rotation=45, ha="right")
plt.yticks(rotation=0)

plt.tight_layout()
plt.show()